import java.util.*;
class Person{
    String name;
    int age;
    void accept(){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the name");
        name=sc.nextLine();
        System.out.println("enter the age");
        age = sc.nextInt();
    }
    void display(){
        System.out.println("the person name is"+name);
        System.out.println("the person age is"+age);
    }
}
public class Main{
    public static void main(String [] args){
        Person p1 = new Person();
        Person p2 = new Person();
        p1.accept();
        p2.accept();
        p1.display();
        p2.display();
        
    }
}
