class Emp
{
    int empno;
    String ename;
    double esal;
    public Emp()
    {
        empno = 101;
        ename = "lasya";
        esal = 90000;
    }
    public void display(){
        System.out.println("the emp no is"+empno);
        System.out.println("the emp name is"+ename);
        System.out.println("the emp sal is"+esal);
    }
}
class Main{
    public static void main(String[] args) {
        Emp e1 = new Emp();
        Emp e2 = new Emp();
        e1.display();
        e2.display();
    }
}
        