final class Animal {
    void sound() {
        System.out.println("Animal makes sound.");
    }
}

// This will cause a compilation error
// class Dog extends Animal { }

public class Main {
    public static void main(String[] args) {
        Animal a = new Animal();
        a.sound();
    }
}