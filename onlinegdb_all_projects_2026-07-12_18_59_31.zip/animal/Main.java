class Animal {
    void display() {
        System.out.println("This is an animal.");
    }
}

class Dog extends Animal {
    void display() {
        super.display();  // Calls parent class method
        System.out.println("This is a dog.");
    }
}

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.display();
    }
}