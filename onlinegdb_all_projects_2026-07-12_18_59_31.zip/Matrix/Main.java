import java.util.*;
class Matrix{
    int data[][];
    Matrix(int r,int c)
      data = new int[r][c];
}
  void getdata(){
      scanner sc=new scanner 
  }