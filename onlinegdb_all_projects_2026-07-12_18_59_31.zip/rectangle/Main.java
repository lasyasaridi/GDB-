import java.util.*;
class Rectangle{
    double length;
    double width;
    Rectangle(){
        length=5;
        width=10;
    }
    Rectangle(double l,double w){
            length=l;
            width=w;
        }
    public double area(){
        return length*width;
    }
}
public class Main{
public static void main(String[] args){
    Rectangle r1=new Rectangle();
    Rectangle r2=new Rectangle(20,13);
    System.out.println(r1.area());
    System.out.println(r2.area());
}
}