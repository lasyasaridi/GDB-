public class Main {
    public static void main(String[] args) {
        Bank b1 = new SBI();
        b1.displayBankInfo();
        System.out.println("Interest Rate: " + b1.getInterestRate() + "%\n");

        Bank b2 = new HDFC();
        b2.displayBankInfo();
        System.out.println("Interest Rate: " + b2.getInterestRate() + "%");
    }
}

abstract class Bank {
    String bankName;

    Bank(String bankName) {
        this.bankName = bankName;
    }


    abstract double getInterestRate();

    
    void displayBankInfo() {
        System.out.println("Bank Name: " + bankName);
    }
}

class SBI extends Bank {
    SBI() {
        super("State Bank of India");
    }

    @Override
    double getInterestRate() {
        return 6.5;
    }
}

class HDFC extends Bank {
    HDFC() {
        super("HDFC Bank");
    }

    @Override
    double getInterestRate() {
        return 7.2;
    }
}