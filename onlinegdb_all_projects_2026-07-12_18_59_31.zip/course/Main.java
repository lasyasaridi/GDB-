class Main {
    static String course = "Java";

    void printCourse() {
        System.out.println(Main.course); 
        System.out.println(course);         
    }

    public static void main(String[] args) {
        new Main().printCourse();
    }
}