class Main{
    static int a= 30;
    static void display(){
        System.out.println("the value of a is"+a);
        
    }
    public static void main(String[] args){
    System.out.println("the value of a is"+a);
    display();
    System.out.println("the value of a is"+Main.a);
    Main.display();
    }   
}