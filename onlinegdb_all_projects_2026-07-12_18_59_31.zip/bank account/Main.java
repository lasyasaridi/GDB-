import java.util.*;
class BankAccount{
    private double balance;
    public BankAccount(double balance){
        this.balance=balance;
    }
    public void deposite(double amt){
        balance=balance+amt;
        System.out.println("Amont deposited successfully");
    }
    public void withdraw(double amt){
        if(amt>balance){
            System.out.println("Insufficent funds");
        }
        else{
            balance=balance-amt;
            System.out.println("The amount withdraw is"+amt);
        }
    }
    public void getBalance(){
        System.out.println("The balance is "+balance);
}
}
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        BankAccount ba=new BankAccount(5000);
        int choice;
        double amt;
        do{
            System.out.println("1.Deposite\n 2.withdraw\n 3.getBalance\n 4.Exit");
            choice=sc.nextInt();
            switch(choice){
                case 1:
                    System.out.println("Enter the amount to deposite");
                    amt=sc.nextDouble();
                    ba.deposite(amt);
                    break;
                case 2:
                    System.out.println("Enter the amount to withdraw");
                    amt=sc.nextDouble();
                    ba.withdraw(amt);
                    break;
                case 3:
                    ba.getBalance();
                    break;
            }
        }while(choice!=4);
    }
}