class Bike{
    String bname;
    float price;
    static int count=0;
    Bike(String bname,float price){
        this.bname=bname;
        this.price=price;
        count++;
    }
    public void bikeCount(){
        System.out.println("The no of bikes are "+count);
    
    }
}
public class Main
{
    public static void main(String[] args){
        Bike b1=new Bike("yamaha",200000);
        Bike b2=new Bike("pulsar",150000);
        b2.bikeCount();
        Bike b3=new Bike("TVS",100000);
        Bike b4=new Bike("Hero",150000);
        b4.bikeCount();
    }
}